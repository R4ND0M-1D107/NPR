#pragma once
extern int sphereNAttribsPerVertex;
extern int sphereNVertices;
extern int sphereNTriangles;
extern float sphereVertices[];
extern unsigned sphereTriangles[];
